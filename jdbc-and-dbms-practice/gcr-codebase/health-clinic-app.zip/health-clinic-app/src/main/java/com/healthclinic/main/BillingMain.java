package com.healthclinic.main;



import java.sql.Date;
import java.util.Scanner;
import com.healthclinic.dao.BillingDAO;

public class BillingMain {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BillingDAO dao = new BillingDAO();

        try {
            while (true) {
                System.out.println("\n----Billing & Payments----");
                System.out.println("1. Generate Bill");
                System.out.println("2. Record Payment");
                System.out.println("3. View Outstanding Bills");
                System.out.println("4. Revenue Report");
                System.out.println("5. Exit");
                System.out.print("Choose option: ");

                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        System.out.print("Enter Visit ID: ");
                        int visitId = Integer.parseInt(sc.nextLine());
                        System.out.print("Enter Additional Charges: ");
                        double addCharges = Double.parseDouble(sc.nextLine());
                        dao.generateBill(visitId, addCharges);
                        break;

                    case 2:
                        System.out.print("Enter Bill ID: ");
                        int billId = Integer.parseInt(sc.nextLine());
                        System.out.print("Enter Payment Mode: ");
                        String mode = sc.nextLine();
                        System.out.print("Enter Amount Paid: ");
                        double amt = Double.parseDouble(sc.nextLine());
                        dao.recordPayment(billId, mode, amt);
                        break;

                    case 3:
                        dao.viewOutstandingBills();
                        break;

                    case 4:
                        System.out.print("Enter Start Date (yyyy-mm-dd): ");
                        Date start = Date.valueOf(sc.nextLine());
                        System.out.print("Enter End Date (yyyy-mm-dd): ");
                        Date end = Date.valueOf(sc.nextLine());
                        dao.generateRevenueReport(start, end);
                        break;

                    case 5:
                        return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
