package com.healthclinic.dao;



import java.sql.*;
import java.util.List;
import com.healthclinic.config.DBConnection;
import com.healthclinic.model.Prescription;

public class VisitDAO {


    // UC-4.1 Record Patient Visit (Transaction)

    public int recordVisit(int appointmentId, String diagnosis, String notes) throws Exception {

        Connection conn = DBConnection.getConnection();
        conn.setAutoCommit(false);

        try {

            String insertVisit = """
                    INSERT INTO visits(appointment_id, diagnosis, notes)
                    VALUES (?, ?, ?)
                    """;

            PreparedStatement ps1 = conn.prepareStatement(insertVisit, Statement.RETURN_GENERATED_KEYS);
            ps1.setInt(1, appointmentId);
            ps1.setString(2, diagnosis);
            ps1.setString(3, notes);

            ps1.executeUpdate();

            ResultSet rs = ps1.getGeneratedKeys();
            rs.next();
            int visitId = rs.getInt(1);

            String updateAppointment = """
                    UPDATE appointments
                    SET status='COMPLETED'
                    WHERE appointment_id=?
                    """;

            PreparedStatement ps2 = conn.prepareStatement(updateAppointment);
            ps2.setInt(1, appointmentId);
            ps2.executeUpdate();

            conn.commit();
            System.out.println("Visit Recorded Successfully!");
            return visitId;

        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.close();
        }
    }


    // UC-4.3 Add Prescription (Batch Insert)

    public void addPrescriptions(int visitId, List<Prescription> prescriptions) throws Exception {

        String sql = """
                INSERT INTO prescriptions(visit_id, medicine_name, dosage, duration)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (Prescription p : prescriptions) {
                ps.setInt(1, visitId);
                ps.setString(2, p.getMedicineName());
                ps.setString(3, p.getDosage());
                ps.setString(4, p.getDuration());
                ps.addBatch();
            }

            ps.executeBatch();
            System.out.println("Prescriptions Added Successfully!");
        }
    }


    // UC-4.2 View Medical History (JOIN + DESC)

    public void viewMedicalHistory(int patientId) throws Exception {

        String sql = """
                SELECT v.visit_id, v.diagnosis, v.notes, v.visit_date,
                       pr.medicine_name, pr.dosage, pr.duration
                FROM visits v
                JOIN appointments a ON v.appointment_id = a.appointment_id
                LEFT JOIN prescriptions pr ON v.visit_id = pr.visit_id
                WHERE a.patient_id=?
                ORDER BY v.visit_date DESC
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                System.out.println("\n----------------------------");
                System.out.println("Visit ID: " + rs.getInt("visit_id"));
                System.out.println("Diagnosis: " + rs.getString("diagnosis"));
                System.out.println("Notes: " + rs.getString("notes"));
                System.out.println("Date: " + rs.getTimestamp("visit_date"));

                String medicine = rs.getString("medicine_name");

                if (medicine != null) {
                    System.out.println("Medicine: " + medicine);
                    System.out.println("Dosage: " + rs.getString("dosage"));
                    System.out.println("Duration: " + rs.getString("duration"));
                }
            }
        }
    }
}
