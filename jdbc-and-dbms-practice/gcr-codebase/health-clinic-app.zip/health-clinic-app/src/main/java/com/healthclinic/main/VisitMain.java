package com.healthclinic.main;


import java.util.*;
import com.healthclinic.dao.VisitDAO;
import com.healthclinic.model.Prescription;

public class VisitMain {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        VisitDAO dao = new VisitDAO();

        try {
            while (true) {

                System.out.println("\n-----Visit Management-----");
                System.out.println("1. Record Visit");
                System.out.println("2. View Medical History");
                System.out.println("3. Exit");
                System.out.print("Choose option: ");

                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {

                    case 1:
                        System.out.print("Enter Appointment ID: ");
                        int apId = Integer.parseInt(sc.nextLine());

                        System.out.print("Enter Diagnosis: ");
                        String diagnosis = sc.nextLine();

                        System.out.print("Enter Notes: ");
                        String notes = sc.nextLine();

                        int visitId = dao.recordVisit(apId, diagnosis, notes);

                        System.out.print("How many medicines to add? ");
                        int count = Integer.parseInt(sc.nextLine());

                        List<Prescription> list = new ArrayList<>();

                        for (int i = 0; i < count; i++) {

                            Prescription p = new Prescription();

                            System.out.print("Medicine Name: ");
                            p.setMedicineName(sc.nextLine());

                            System.out.print("Dosage: ");
                            p.setDosage(sc.nextLine());

                            System.out.print("Duration: ");
                            p.setDuration(sc.nextLine());

                            list.add(p);
                        }

                        dao.addPrescriptions(visitId, list);
                        break;

                    case 2:
                        System.out.print("Enter Patient ID: ");
                        dao.viewMedicalHistory(Integer.parseInt(sc.nextLine()));
                        break;

                    case 3:
                        return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
