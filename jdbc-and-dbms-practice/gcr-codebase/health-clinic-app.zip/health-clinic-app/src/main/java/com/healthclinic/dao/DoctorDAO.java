//package com.healthclinic.dao;
//
//
//
//import java.sql.*;
//import com.healthclinic.config.DBConnection;
//import com.healthclinic.model.Doctor;
//
//public class DoctorDAO {
//
//
//    // UC-2.1 Add Doctor
//
//    public void addDoctor(Doctor doctor) throws Exception {
//
//        String sql = "INSERT INTO doctors(name, contact, consultation_fee, specialty_id) VALUES (?, ?, ?, ?)";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            ps.setString(1, doctor.getName());
//            ps.setString(2, doctor.getContact());
//            ps.setDouble(3, doctor.getConsultationFee());
//            ps.setInt(4, doctor.getSpecialtyId());
//
//            ps.executeUpdate();
//            System.out.println("Doctor Added Successfully!");
//        }
//    }
//
//
//    // Show Specialties
//
//    public void showSpecialties() throws Exception {
//
//        String sql = "SELECT * FROM specialties";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql);
//             ResultSet rs = ps.executeQuery()) {
//
//            System.out.println("Available Specialties:");
//            while (rs.next()) {
//                System.out.println(rs.getInt("specialty_id") + " - " +
//                        rs.getString("specialty_name"));
//            }
//        }
//    }
//
//
//    // UC-2.2 Update Specialty (Transaction)
//
//    public void updateDoctorSpecialty(int doctorId, int specialtyId) throws Exception {
//
//        Connection conn = DBConnection.getConnection();
//        conn.setAutoCommit(false);
//
//        try {
//
//            String check = "SELECT * FROM specialties WHERE specialty_id=?";
//            PreparedStatement ps1 = conn.prepareStatement(check);
//            ps1.setInt(1, specialtyId);
//            ResultSet rs = ps1.executeQuery();
//
//            if (!rs.next()) {
//                System.out.println("Invalid Specialty ID!");
//                conn.rollback();
//                return;
//            }
//
//            String update = "UPDATE doctors SET specialty_id=? WHERE doctor_id=?";
//            PreparedStatement ps2 = conn.prepareStatement(update);
//            ps2.setInt(1, specialtyId);
//            ps2.setInt(2, doctorId);
//            ps2.executeUpdate();
//
//            conn.commit();
//            System.out.println("Doctor Specialty Updated Successfully!");
//
//        } catch (Exception e) {
//            conn.rollback();
//            e.printStackTrace();
//        } finally {
//            conn.close();
//        }
//    }
//
//
//    // UC-2.3 View Doctors by Specialty (JOIN)
//
//    public void viewDoctorsBySpecialty(String specialtyName) throws Exception {
//
//        String sql = """
//                SELECT d.doctor_id, d.name, d.contact, d.consultation_fee, s.specialty_name
//                FROM doctors d
//                JOIN specialties s ON d.specialty_id = s.specialty_id
//                WHERE s.specialty_name = ?
//                AND d.is_active = TRUE
//                """;
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            ps.setString(1, specialtyName);
//            ResultSet rs = ps.executeQuery();
//
//            while (rs.next()) {
//                System.out.println("----------------------------");
//                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
//                System.out.println("Name: " + rs.getString("name"));
//                System.out.println("Contact: " + rs.getString("contact"));
//                System.out.println("Fee: " + rs.getDouble("consultation_fee"));
//                System.out.println("Specialty: " + rs.getString("specialty_name"));
//            }
//        }
//    }
//
//
//    // UC-2.4 Deactivate Doctor
//
//    public void deactivateDoctor(int doctorId) throws Exception {
//
//        String checkAppointments = """
//                SELECT COUNT(*) FROM appointments
//                WHERE doctor_id = ?
//                AND appointment_date >= CURDATE()
//                AND status = 'SCHEDULED'
//                """;
//
//        String deactivate = "UPDATE doctors SET is_active = FALSE WHERE doctor_id=?";
//
//        try (Connection conn = DBConnection.getConnection()) {
//
//            PreparedStatement ps1 = conn.prepareStatement(checkAppointments);
//            ps1.setInt(1, doctorId);
//            ResultSet rs = ps1.executeQuery();
//            rs.next();
//
//            if (rs.getInt(1) > 0) {
//                System.out.println("Doctor has future appointments. Cannot deactivate.");
//                return;
//            }
//
//            PreparedStatement ps2 = conn.prepareStatement(deactivate);
//            ps2.setInt(1, doctorId);
//            ps2.executeUpdate();
//
//            System.out.println("Doctor Deactivated Successfully!");
//        }
//    }
//}

package com.healthclinic.dao;

import java.sql.*;
import com.healthclinic.config.DBConnection;
import com.healthclinic.model.Doctor;

public class DoctorDAO {


    public void addDoctor(Doctor doctor) throws Exception {

        String sql = "INSERT INTO doctors(name, contact, consultation_fee, specialty_id, is_active) VALUES (?, ?, ?, ?, TRUE)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, doctor.getName());
            ps.setString(2, doctor.getContact());
            ps.setDouble(3, doctor.getConsultationFee());
            ps.setInt(4, doctor.getSpecialtyId());

            ps.executeUpdate();
            System.out.println("Doctor Added Successfully!");
        }
    }


    public void showSpecialties() throws Exception {

        String sql = "SELECT * FROM specialties";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("Available Specialties:");
            while (rs.next()) {
                System.out.println(rs.getInt("specialty_id") + " - " +
                                   rs.getString("specialty_name"));
            }
        }
    }


    public void updateDoctorSpecialty(int doctorId, int specialtyId) throws Exception {

        String sql = "UPDATE doctors SET specialty_id=? WHERE doctor_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, specialtyId);
            ps.setInt(2, doctorId);

            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Doctor Specialty Updated Successfully!");
            else
                System.out.println("Doctor Not Found!");
        }
    }


    public void viewDoctorsBySpecialty(int specialtyId) throws Exception {

        String sql = """
                SELECT d.doctor_id, d.name, d.contact, d.consultation_fee, s.specialty_name
                FROM doctors d
                JOIN specialties s ON d.specialty_id = s.specialty_id
                WHERE s.specialty_id = ?
                AND d.is_active = TRUE
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, specialtyId);
            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while (rs.next()) {
                found = true;
                System.out.println("----------------------------");
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Contact: " + rs.getString("contact"));
                System.out.println("Fee: " + rs.getDouble("consultation_fee"));
                System.out.println("Specialty: " + rs.getString("specialty_name"));
            }

            if (!found)
                System.out.println("No doctors found for this specialty.");
        }
    }


    public void deactivateDoctor(int doctorId) throws Exception {

        String sql = "UPDATE doctors SET is_active = FALSE WHERE doctor_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, doctorId);
            int rows = ps.executeUpdate();

            if (rows > 0)
                System.out.println("Doctor Deactivated Successfully!");
            else
                System.out.println("Doctor Not Found!");
        }
    }
}
