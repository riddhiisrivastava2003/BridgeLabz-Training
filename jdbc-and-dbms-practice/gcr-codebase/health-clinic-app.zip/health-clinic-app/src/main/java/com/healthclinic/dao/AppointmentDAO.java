package com.healthclinic.dao;

import java.sql.*;
import com.healthclinic.config.DBConnection;

public class AppointmentDAO {

    // UC-3.1 Book Appointment
    public void bookAppointment(int patientId, int doctorId, Date date, Time time) throws Exception {


        String check = """
                SELECT COUNT(*) FROM appointments
                WHERE doctor_id=? AND appointment_date=? AND appointment_time=?
                AND status='SCHEDULED'
                """;



        String insert = """
                INSERT INTO appointments(patient_id, doctor_id, appointment_date, appointment_time, status)
                VALUES (?,?,?,?,'SCHEDULED')
                """;

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps1 = conn.prepareStatement(check);
            ps1.setInt(1, doctorId);
            ps1.setDate(2, date);
            ps1.setTime(3, time);

            ResultSet rs = ps1.executeQuery();
            rs.next();

            if (rs.getInt(1) > 0) {
                System.out.println("Slot already booked!");
                return;
            }

            PreparedStatement ps2 = conn.prepareStatement(insert);
            ps2.setInt(1, patientId);
            ps2.setInt(2, doctorId);
            ps2.setDate(3, date);
            ps2.setTime(4, time);

            ps2.executeUpdate();
            System.out.println("Appointment Booked Successfully!");
        }
    }

    // UC-3.2 Check Doctor Availability
    public void checkAvailability(int doctorId, Date date) throws Exception {

        String sql = """
                SELECT appointment_time, COUNT(*) AS total
                FROM appointments
                WHERE doctor_id=? AND appointment_date=? AND status='SCHEDULED'
                GROUP BY appointment_time
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, doctorId);
            ps.setDate(2, date);

            ResultSet rs = ps.executeQuery();

            System.out.println("Booked Slots:");
            while (rs.next()) {
                System.out.println("Time: " + rs.getTime("appointment_time") +
                        " | Bookings: " + rs.getInt("total"));
            }
        }
    }

    // UC-3.3 Cancel Appointment (Transaction + Audit)

    public void cancelAppointment(int appointmentId) throws Exception {

        Connection conn = DBConnection.getConnection();
        conn.setAutoCommit(false);

        try {
            String update = "UPDATE appointments SET status='CANCELLED' WHERE appointment_id=?";
            PreparedStatement ps1 = conn.prepareStatement(update);
            ps1.setInt(1, appointmentId);
            ps1.executeUpdate();

            String audit = """
                    INSERT INTO appointment_audit(appointment_id, action_type)
                    VALUES (?, 'CANCELLED')
                    """;

            PreparedStatement ps2 = conn.prepareStatement(audit);
            ps2.setInt(1, appointmentId);
            ps2.executeUpdate();

            conn.commit();
            System.out.println("Appointment Cancelled Successfully!");
        } catch (Exception e) {
            conn.rollback();
            e.printStackTrace();
        } finally {
            conn.close();
        }
    }


    // UC-3.4 Reschedule Appointment (Transaction)

    public void rescheduleAppointment(int appointmentId, Date newDate, Time newTime) throws Exception {

        Connection conn = DBConnection.getConnection();
        conn.setAutoCommit(false);
        try {

            String getDoctor = "SELECT doctor_id FROM appointments WHERE appointment_id=?";
            PreparedStatement ps0 = conn.prepareStatement(getDoctor);
            ps0.setInt(1, appointmentId);
            ResultSet rs0 = ps0.executeQuery();
            rs0.next();
            int doctorId = rs0.getInt("doctor_id");

            String check = """
                    SELECT COUNT(*) FROM appointments
                    WHERE doctor_id=? AND appointment_date=? AND appointment_time=?
                    AND status='SCHEDULED'
                    """;

            PreparedStatement ps1 = conn.prepareStatement(check);
            ps1.setInt(1, doctorId);
            ps1.setDate(2, newDate);
            ps1.setTime(3, newTime);

            ResultSet rs = ps1.executeQuery();
            rs.next();

            if (rs.getInt(1) > 0) {
                System.out.println("New slot already booked!");
                conn.rollback();
                return;
            }

            String update = """
                    UPDATE appointments
                    SET appointment_date=?, appointment_time=?
                    WHERE appointment_id=?
                    """;

            PreparedStatement ps2 = conn.prepareStatement(update);
            ps2.setDate(1, newDate);
            ps2.setTime(2, newTime);
            ps2.setInt(3, appointmentId);

            ps2.executeUpdate();
            conn.commit();

            System.out.println("Appointment Rescheduled Successfully!");

        } catch (Exception e) {
            conn.rollback();
            e.printStackTrace();
        } finally {
            conn.close();
        }
    }

    // UC-3.5 View Daily Schedule (JOIN)

    public void viewDailySchedule(Date date) throws Exception {

        String sql = """
                SELECT a.appointment_id, p.name AS patient_name,
                       d.name AS doctor_name,
                       a.appointment_time, a.status
                FROM appointments a
                JOIN patients p ON a.patient_id = p.patient_id
                JOIN doctors d ON a.doctor_id = d.doctor_id
                WHERE a.appointment_date=?
                ORDER BY a.appointment_time
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("-----------------------------");
                System.out.println("Appointment ID: " + rs.getInt("appointment_id"));
                System.out.println("Patient: " + rs.getString("patient_name"));
                System.out.println("Doctor: " + rs.getString("doctor_name"));
                System.out.println("Time: " + rs.getTime("appointment_time"));
                System.out.println("Status: " + rs.getString("status"));
            }
        }
    }
}
