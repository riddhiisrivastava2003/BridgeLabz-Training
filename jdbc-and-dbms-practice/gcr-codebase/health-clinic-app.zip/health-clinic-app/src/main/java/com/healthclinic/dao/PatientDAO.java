package com.healthclinic.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.healthclinic.config.DBConnection;
import com.healthclinic.model.Patient;

public class PatientDAO {

    // ==============================
    // UC-1.1 Check uniqueness
    // ==============================
    public boolean isPatientExists(String phone, String email) throws Exception {

        String sql = "SELECT * FROM patients WHERE phone=? OR email=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, phone);
            ps.setString(2, email);

            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }


    // UC-1.1 Register patient

    public void registerPatient(Patient patient) throws Exception {

        if (isPatientExists(patient.getPhone(), patient.getEmail())) {
            System.out.println("Patient already exists!");
            return;
        }

        String sql = "INSERT INTO patients(name,dob,phone,email,address,blood_group) VALUES(?,?,?,?,?,?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, patient.getName());
            ps.setDate(2, patient.getDob());
            ps.setString(3, patient.getPhone());
            ps.setString(4, patient.getEmail());
            ps.setString(5, patient.getAddress());
            ps.setString(6, patient.getBloodGroup());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                System.out.println("Patient Registered Successfully! ID: " + rs.getInt(1));
            }
        }
    }


    // UC-1.2 Search by ID or Phone

    public Patient findPatient(String input) throws Exception {

        String sql = "SELECT * FROM patients WHERE patient_id=? OR phone=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            try {
                ps.setInt(1, Integer.parseInt(input));
            } catch (NumberFormatException e) {
                ps.setInt(1, 0);
            }

            ps.setString(2, input);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Patient p = new Patient();
                p.setPatientId(rs.getInt("patient_id"));
                p.setName(rs.getString("name"));
                p.setDob(rs.getDate("dob"));
                p.setPhone(rs.getString("phone"));
                p.setEmail(rs.getString("email"));
                p.setAddress(rs.getString("address"));
                p.setBloodGroup(rs.getString("blood_group"));
                return p;
            }
        }
        return null;
    }

    // UC-1.2 Update Patient

    public void updatePatient(Patient patient) throws Exception {

        String sql = "UPDATE patients SET name=?, dob=?, phone=?, email=?, address=?, blood_group=? WHERE patient_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, patient.getName());
            ps.setDate(2, patient.getDob());
            ps.setString(3, patient.getPhone());
            ps.setString(4, patient.getEmail());
            ps.setString(5, patient.getAddress());
            ps.setString(6, patient.getBloodGroup());
            ps.setInt(7, patient.getPatientId());

            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("Patient Updated Successfully!");
            else
                System.out.println("Patient Not Found!");
        }
    }


    // UC-1.3 Search by Name (LIKE)

    public void searchByName(String name) throws Exception {

        String sql = "SELECT * FROM patients WHERE name LIKE ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + name + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("patient_id") +
                        " | Name: " + rs.getString("name") +
                        " | Phone: " + rs.getString("phone"));
            }
        }
    }


    // UC-1.4 View Visit History

    public void viewVisitHistory(int patientId) throws Exception {

        String sql = "SELECT a.appointment_date, d.name AS doctor_name, v.diagnosis " +
                "FROM appointments a " +
                "JOIN visits v ON a.appointment_id = v.appointment_id " +
                "JOIN doctors d ON a.doctor_id = d.doctor_id " +
                "WHERE a.patient_id = ? " +
                "ORDER BY a.appointment_date ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("Date: " + rs.getDate("appointment_date") +
                        " | Doctor: " + rs.getString("doctor_name") +
                        " | Diagnosis: " + rs.getString("diagnosis"));
            }
        }
    }
}
