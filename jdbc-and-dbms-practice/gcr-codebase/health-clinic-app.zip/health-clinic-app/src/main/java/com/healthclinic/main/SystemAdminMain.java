package com.healthclinic.main;



import java.util.List;
import java.util.Scanner;
import com.healthclinic.dao.SpecialtyDAO;
import com.healthclinic.dao.AuditDAO;
import com.healthclinic.model.Specialty;
import com.healthclinic.model.AuditLog;

public class SystemAdminMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SpecialtyDAO specialtyDAO = new SpecialtyDAO();
        AuditDAO auditDAO = new AuditDAO();

        while(true) {
            System.out.println("\n-----System Administration-----");
            System.out.println("1. Add Specialty");
            System.out.println("2. Update Specialty");
            System.out.println("3. Delete Specialty");
            System.out.println("4. View Audit Logs");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");
            int choice = sc.nextInt(); sc.nextLine();

            try {
                switch(choice) {
                    case 1:
                        System.out.print("Enter Specialty Name: ");
                        String name = sc.nextLine();
                        specialtyDAO.addSpecialty(name);
                        break;
                    case 2:
                        List<Specialty> list = specialtyDAO.getAllSpecialties();
                        list.forEach(s -> System.out.println(s.getSpecialtyId() + " - " + s.getSpecialtyName()));
                        System.out.print("Enter Specialty ID to update: ");
                        int id = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter New Name: ");
                        String newName = sc.nextLine();
                        specialtyDAO.updateSpecialty(id, newName);
                        break;
                    case 3:
                        List<Specialty> delList = specialtyDAO.getAllSpecialties();
                        delList.forEach(s -> System.out.println(s.getSpecialtyId() + " - " + s.getSpecialtyName()));
                        System.out.print("Enter Specialty ID to delete: ");
                        int delId = sc.nextInt(); sc.nextLine();
                        specialtyDAO.deleteSpecialty(delId);
                        break;
                    case 4:
                        System.out.print("Filter by table name (optional): ");
                        String tableFilter = sc.nextLine();
                        List<AuditLog> logs = auditDAO.getAuditLogs(tableFilter, null);
                        logs.forEach(l -> System.out.println(l.getAuditId() + " | " + l.getActionType() + " | " + l.getRemarks() + " | " + l.getActionTime()));
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        sc.close();
                        System.exit(0);
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
}
