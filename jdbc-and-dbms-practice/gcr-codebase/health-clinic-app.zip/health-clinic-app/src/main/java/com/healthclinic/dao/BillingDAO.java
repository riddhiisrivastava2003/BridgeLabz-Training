package com.healthclinic.dao;


import java.sql.*;
import com.healthclinic.config.DBConnection;

public class BillingDAO {

    // UC-5.1 Generate Bill for Visit
    public void generateBill(int visitId, double additionalCharges) throws Exception {
        String sql = """
                INSERT INTO bills(visit_id, total_amount)
                VALUES(?, (
                    SELECT d.consultation_fee + ? 
                    FROM appointments a 
                    JOIN doctors d ON a.doctor_id=d.doctor_id
                    WHERE a.appointment_id=?
                ))
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, visitId);
            ps.setDouble(2, additionalCharges);
            ps.setInt(3, visitId);

            ps.executeUpdate();
            System.out.println("Bill Generated Successfully!");
        }
    }

    // UC-5.2 Record Payment
    public void recordPayment(int billId, String paymentMode, double amount) throws Exception {
        Connection conn = DBConnection.getConnection();
        conn.setAutoCommit(false);

        try {
            String updateBill = """
                    UPDATE bills 
                    SET payment_status='PAID', payment_date=CURDATE() 
                    WHERE bill_id=?
                    """;
            PreparedStatement ps1 = conn.prepareStatement(updateBill);
            ps1.setInt(1, billId);
            ps1.executeUpdate();

            String insertTransaction = """
                    INSERT INTO payment_transactions(bill_id, payment_mode, amount)
                    VALUES (?, ?, ?)
                    """;
            PreparedStatement ps2 = conn.prepareStatement(insertTransaction);
            ps2.setInt(1, billId);
            ps2.setString(2, paymentMode);
            ps2.setDouble(3, amount);
            ps2.executeUpdate();

            conn.commit();
            System.out.println("Payment Recorded Successfully!");
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.close();
        }
    }

    // UC-5.3 View Outstanding Bills
    public void viewOutstandingBills() throws Exception {
        String sql = """
                SELECT p.name, SUM(b.total_amount) AS total_due, COUNT(*) AS bills_count
                FROM bills b
                JOIN visits v ON b.visit_id = v.visit_id
                JOIN patients p ON v.patient_id = p.patient_id
                WHERE b.payment_status='UNPAID'
                GROUP BY p.patient_id, p.name
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("----------------------------");
                System.out.println("Patient: " + rs.getString("name"));
                System.out.println("Total Due: " + rs.getDouble("total_due"));
                System.out.println("Number of Bills: " + rs.getInt("bills_count"));
            }
        }
    }

    // UC-5.4 Revenue Report
    public void generateRevenueReport(Date startDate, Date endDate) throws Exception {
        String sql = """
                SELECT d.name AS doctor_name, s.specialty_name, SUM(b.total_amount) AS revenue
                FROM bills b
                JOIN visits v ON b.visit_id = v.visit_id
                JOIN appointments a ON v.appointment_id = a.appointment_id
                JOIN doctors d ON a.doctor_id = d.doctor_id
                JOIN specialties s ON d.specialty_id = s.specialty_id
                WHERE b.payment_date BETWEEN ? AND ?
                GROUP BY d.doctor_id, s.specialty_id, d.name, s.specialty_name
                HAVING revenue > 0
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, startDate);
            ps.setDate(2, endDate);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("----------------------------");
                System.out.println("Doctor: " + rs.getString("doctor_name"));
                System.out.println("Specialty: " + rs.getString("specialty_name"));
                System.out.println("Revenue: " + rs.getDouble("revenue"));
            }
        }
    }
}
