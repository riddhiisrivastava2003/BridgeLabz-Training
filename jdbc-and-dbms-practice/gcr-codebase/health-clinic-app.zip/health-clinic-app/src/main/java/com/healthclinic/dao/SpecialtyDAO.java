package com.healthclinic.dao;



import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.healthclinic.config.DBConnection;
import com.healthclinic.model.Specialty;

public class SpecialtyDAO {

    // Create Specialty
    public void addSpecialty(String name) throws Exception {
        String sql = "INSERT INTO specialties(specialty_name) VALUES(?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.executeUpdate();
            System.out.println("Specialty added successfully!");
        }
    }

    // Read all specialties
    public List<Specialty> getAllSpecialties() throws Exception {
        List<Specialty> list = new ArrayList<>();
        String sql = "SELECT * FROM specialties";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Specialty s = new Specialty();
                s.setSpecialtyId(rs.getInt("specialty_id"));
                s.setSpecialtyName(rs.getString("specialty_name"));
                list.add(s);
            }
        }
        return list;
    }

    // Update Specialty
    public void updateSpecialty(int id, String newName) throws Exception {
        String sql = "UPDATE specialties SET specialty_name=? WHERE specialty_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newName);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Specialty updated successfully!");
        }
    }

    // Delete Specialty (check foreign key constraints)
    public void deleteSpecialty(int id) throws Exception {
        String checkSql = "SELECT COUNT(*) AS count FROM doctors WHERE specialty_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
            psCheck.setInt(1, id);
            ResultSet rs = psCheck.executeQuery();
            rs.next();
            if (rs.getInt("count") > 0) {
                System.out.println("Cannot delete. Specialty is assigned to doctors.");
                return;
            }
        }

        String sql = "DELETE FROM specialties WHERE specialty_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Specialty deleted successfully!");
        }
    }
}
